package com.capstore.repo;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.entity.Cart;
@Repository
public interface CartRepo extends CrudRepository<Cart, Integer> {

	@Modifying
	@Query(value = "insert into cart_product (CART_ID,PRODUCT_ID) values(:cartId, :prodId)", nativeQuery = true)
	@Transactional
	void insertProductIntoCart(@Param("cartId") int cartID, @Param("prodId") int productId);
}
