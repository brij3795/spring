package com.capstore.service;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.entity.Product;
import com.capstore.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo repo;

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveProduct(Product p) {
		repo.save(p);
	}

	@Transactional
	public Iterable<Product> getAll() {
		return repo.findAll();
	}

	@Transactional
	public Product getProduct(int id) {
		return repo.findById(id).get();
	}

	@Transactional
	public String deleteProduct(int id) {
		Product p1 = repo.findById(id).get();
		repo.delete(p1);
		return "Delete Successfully";

	}
}
