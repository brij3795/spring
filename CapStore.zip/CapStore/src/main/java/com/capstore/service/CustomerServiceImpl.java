package com.capstore.service;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.entity.Customer;
import com.capstore.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo repo;

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveCustomer(Customer c) {
		repo.save(c);
	}

	@Transactional
	public Iterable<Customer> getAll1() {
		return repo.findAll();
	}

	@Transactional
	public Customer getCustomer(int id) {
		return repo.findById(id).get();
	}

	@Transactional
	public String deleteCustomer1(int id) {
		Customer c1 = repo.findById(id).get();
		repo.delete(c1);
		return "Delete Successfully";

	}

}