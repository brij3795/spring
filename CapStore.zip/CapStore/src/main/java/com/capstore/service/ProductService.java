package com.capstore.service;
/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import org.springframework.stereotype.Service;

import com.capstore.entity.Product;

@Service
public interface ProductService {
	
	void saveProduct(Product p);
	
	Iterable<Product> getAll();
	
	public String deleteProduct(int id);
	
	 Product getProduct(int id);
}
