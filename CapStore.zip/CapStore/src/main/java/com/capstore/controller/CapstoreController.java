package com.capstore.controller;

import java.util.List;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.entity.Cart;
import com.capstore.entity.CartProduct;
import com.capstore.entity.Customer;
import com.capstore.entity.Product;
import com.capstore.service.CartService;
import com.capstore.service.CustomerService;
import com.capstore.service.ProductService;

@RestController
public class CapstoreController {

	@Autowired
	private ProductService pservice;
	@Autowired
	private CustomerService cservice;

	@Autowired
	private CartService cartService;

	@GetMapping("/hi")
	public String get() {
		return "Hi spring";
	}

	@GetMapping("/allproduct")
	public Iterable<Product> getAll() {
		return pservice.getAll();
	}

	@PostMapping(path = "/add/customer", consumes = "application/json")
	public String saveCustomer(@RequestBody Customer c) {
		cservice.saveCustomer(c);
		return "Customer Saved";
	}

	@DeleteMapping(path = "/deletecustomer/{id}")
	public String delete1(@PathVariable("id") int id) {
		return cservice.deleteCustomer1(id);
	}

	@GetMapping("/allcustomer")
	public Iterable<Customer> getAll1() {
		return cservice.getAll1();
	}

	@PostMapping(path = "/add/product", consumes = "application/json")
	public String saveProduct(@RequestBody Product p) {
		pservice.saveProduct(p);
		return "Product Saved";
	}

	@DeleteMapping(path = "/deleteproduct/{id}")
	public String delete(@PathVariable("id") int id) {
		return pservice.deleteProduct(id);
	}

	@PostMapping(path = "/addtocart/{custId}/{productId}", consumes = "application/json", produces = "application/json")
	public String addToCart(@PathVariable("custId") int custId, @PathVariable("productId") int productId,
			@RequestBody Cart cart) {
		System.out.println(cart.getCartProducts());
		Customer cust = cservice.getCustomer(custId);
		Product prod = pservice.getProduct(productId);
		cart.setCustomerFromCart(cust);
		CartProduct cartProd = new CartProduct();
		cartProd.setCart(cart);
		cartProd.setProduct(prod);
		cart.addCartProduct(cartProd);
		cartService.saveCart(cart);
		return "product added to cart";
	}

	@GetMapping(path = "/cartproduct/{custId}", consumes = "application/json", produces = "application/json")
	public List<CartProduct> cartProducts(@PathVariable int custId) {
		Customer cust = cservice.getCustomer(custId);
		Cart cart = cust.getCart();
		return cart.getCartProducts();
	}

}
