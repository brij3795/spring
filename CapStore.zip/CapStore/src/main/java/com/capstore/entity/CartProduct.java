package com.capstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "cart_products")
public class CartProduct {

	@Id
	@Column(name = "cp_id", length = 10)
	@GeneratedValue
	private int id;

	@JsonBackReference(value = "cart_product")
	@ManyToOne
	@JoinColumn(name = "cart_id")
	private Cart cart;

	@JsonBackReference(value = "product-cart")
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product productFromCartProduct;

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public Product getProduct() {
		return productFromCartProduct;
	}

	public void setProduct(Product product) {
		this.productFromCartProduct = product;
	}

}
