package com.capstore.entity;
/*
/ * Author :- Mayuresh Shinde 173560
 * version:- 1.0.1
 */

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "customer")
public class Customer {
	@Id
	@Column(name = "customer_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "customer_seq")
	@SequenceGenerator(name = "customer_seq", sequenceName = "customer_seq")
	private int id;

	@Column(name = "customer_firstname", length = 25)
	private String firstName;

	@Column(name = "customer_lastname", length = 25)
	private String lastName;

	@Column(name = "customer_email", length = 64)
	private String email;

	@Column(name = "customer_password", length = 50)
	private String password;

	@Column(name = "customer_contact")
	private String contact;

	@Column(name = "is_customer_activated", length = 3)
	private String isActive;

	/************** Relationships ******************/
	// @OneToOne(mappedBy = "customerFromWishList")
	// private WishList wishList;
	//
	// @JsonManagedReference(value="customer-address")
	// @OneToMany(mappedBy = "customerFromAddress", fetch = FetchType.LAZY, cascade
	// = CascadeType.ALL)
	// private List<Address> address = new ArrayList<Address>();
	//
	@JsonIgnore
	@OneToOne(mappedBy = "customerFromCart", cascade = CascadeType.ALL)
	private Cart cart;
	//
	// @JsonManagedReference(value="customer-order")
	// @OneToMany(mappedBy = "customerFromOrder", fetch = FetchType.LAZY, cascade =
	// CascadeType.ALL)
	// private List<Order> orders = new ArrayList<Order>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	// @JsonIgnore
	// public WishList getWishList() {
	// return wishList;
	// }
	//
	// public void setWishList(WishList wishList) {
	// this.wishList = wishList;
	// }
	//
	// @JsonIgnore
	// public List<Address> getAddress() {
	// return address;
	// }
	//
	// public void setAddress(List<Address> address) {
	// this.address = address;
	// }
	//
	// public void addAddress(Address address) {
	// address.setCustomer(this);
	// this.getAddress().add(address);
	// }
	//
	
	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}
	//
	// @JsonIgnore
	// public List<Order> getOrders() {
	// return orders;
	// }
	//
	// public void setOrders(List<Order> orders) {
	// this.orders = orders;
	// }
	//
	// public void addOrder(Order order) {
	// order.setCustomerFromOrder(this);
	// this.getOrders().add(order);
	// }
	//
	// }
}