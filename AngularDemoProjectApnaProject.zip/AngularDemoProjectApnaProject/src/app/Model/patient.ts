export class Patient{
   id:number;
   patientFirstName:String; 
   patientLastName:String;
   patientDOB:String;
   patientGender:String;
   patientMobile:String;
   patientEmail:String;
   patientBloodGroup:String;
}