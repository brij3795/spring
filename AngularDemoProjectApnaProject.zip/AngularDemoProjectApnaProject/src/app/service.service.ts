import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Patient } from './Model/patient';
import { Observable } from 'rxjs';
import { User } from './Model/user';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  baseUrl = "http://localhost:8888";

  constructor(private http:HttpClient) { }


  addPatient(patient:Patient)
  {
    return this.http.post<Patient>(this.baseUrl+  '/addPatient', patient);
  }

  getPatient(): Observable<Patient[]> {
      return this.http.get<Patient[]>(this.baseUrl+  '/getPatient');
  }


  addUser(user:User)
  {
    return this.http.post<User>(this.baseUrl+ '/addUser', user);
  }

  getUser(): Observable<User[]> {
    return this.http.get<User[]>(this.baseUrl+  '/getUser');
}
}
