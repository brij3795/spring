import { Component, OnInit, Input } from '@angular/core';
import { Patient } from '../model/patientdetails';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-patientdetails',
  templateUrl: './patientdetails.component.html',
  styleUrls: ['./patientdetails.component.css']
})
export class PatientdetailsComponent implements OnInit {
 
  patientdetailsArr: Patient[] = [];
  patientArr: Patient[] = [];
  allEmailId: [];
  trial: any;
  emailCheck: boolean;
  patient: Patient;
  constructor(private service: ServiceService, private router: Router) {
    this.patient = new Patient();

  }


  ngOnInit() {

  }
  addPatient() {
    this.service.addPatient(this.patient).subscribe(
      data => {
        console.log(data);
      
        this.router.navigate(['/admin']);
        
      });
  }

  getPatients() {
    this.service.getPatient().subscribe(res=>{
      this.patientArr=res;
      if(this.patientArr.length===0)
      {
      this.addPatient();
      this.router.navigate(['/admin']);
    }
    
    for (const u of this.patientArr) {
    
      if (this.patient.patientEmail !== u.patientEmail ) {
        this.emailCheck = true;
    }
    else {
      this.emailCheck = false;
      alert('patient id  already exists');
      break;
    }
  }
  if (this.emailCheck) {
    this.addPatient();
    this.router.navigate(['/admin']);
  }
  
  });
}
 

}
