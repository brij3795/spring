import { Component, OnInit } from '@angular/core';
import { Patient } from '../Model/patient';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css']
})
export class PatientComponent implements OnInit {

  patientArr:Patient[]=[];
  patient:Patient;
  constructor(private service:ServiceService,private router:Router) {
    this.patient=new Patient();
   }

  ngOnInit() {
  }

  addPatient()
  {
    this.service.addPatient(this.patient).subscribe(
      data=>{
        console.log(data);
        this.router.navigate(['/admin']);
      }
    );
  }


  getPatients(){
    this.service.getPatient
  }
}
