import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Patient } from '../Model/patient';
import { jsonpCallbackContext } from '@angular/common/http/src/module';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {


  patientArr:Patient[]=[];
  patient:Patient;
  constructor(private router: Router, private service: ServiceService) { }

  ngOnInit() {
    console.log(this.patientArr);
    this.service.getPatient().subscribe(res=>{
      this.patientArr=res;
    JSON.stringify(this.patientArr);
     //console.log(this.patientArr);
    return this.patientArr;
    });
  }

  
   
  

}
