package com.capstore.entity;



import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "wishlist")
public class WishList {

	@Id
	@Column(name = "wishlist_id", length = 10)
	@GeneratedValue
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public Customer getCustomer() {
		return customerFromWishList;
	}

	public void setCustomer(Customer customer) {
		this.customerFromWishList = customer;
	}

	public Customer getCustomerFromWishList() {
		return customerFromWishList;
	}

	public void setCustomerFromWishList(Customer customerFromWishList) {
		this.customerFromWishList = customerFromWishList;
	}

	public void addProduct(Product product) {
		this.getProduct().add(product);
	}

	/************** Relationships ******************/
	@ManyToMany
	@JoinTable(name = "product_wishlist", joinColumns = { @JoinColumn(name = "wishlist_id") }, inverseJoinColumns = {
			@JoinColumn(name = "product_id") })
	private List<Product> product = new ArrayList<Product>();

	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customerFromWishList;
}