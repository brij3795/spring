package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.entity.Customer;
import com.capstore.entity.WishList;



public interface WishlistRepo extends CrudRepository<WishList, Integer>{

	
}
