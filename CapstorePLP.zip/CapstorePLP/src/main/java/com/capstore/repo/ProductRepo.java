package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.entity.Product;

public interface ProductRepo extends CrudRepository<Product, Integer>{

}
