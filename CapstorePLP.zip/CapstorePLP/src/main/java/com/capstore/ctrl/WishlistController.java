package com.capstore.ctrl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstore.entity.Customer;
import com.capstore.entity.Product;
import com.capstore.service.WishlistService;
import com.capstore.service.WishlistServiceImpl;


public class WishlistController {

	@Autowired
	WishlistService service= new WishlistServiceImpl();
	
//	@GetMapping("/wishlist")
//	public List<Product> getAllProducts() {
//		return service.getAllProducts();
//	}
	
	
	@PostMapping("/addProduct")
	public String addProduct(
			@RequestParam ("name") String name,@RequestParam ("brand") String brand) {
		Product product=new Product();
		product.setName("name");
		product.setBrand("brand");
		service.addProduct(product);
	 return "Product Saved to wishlist successfully";
	 }
	
	
	@GetMapping("/addCustomer")
	public String addCustomer(@RequestBody Customer customer) {
		 service.addCustomer(customer);
		 return "Customer added to wishlist records";
	}
}
