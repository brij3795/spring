package com.capstore.service;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;

import com.capstore.entity.Customer;
import com.capstore.entity.Product;

public interface WishlistService {

	//public List<Product> getAllProducts();
	public String addProduct(@RequestBody Product product );
	public String addCustomer( Customer customer);
}
