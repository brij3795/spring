package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.capstore.entity.Customer;
import com.capstore.entity.Product;
import com.capstore.entity.WishList;
import com.capstore.repo.ProductRepo;
import com.capstore.repo.WishlistRepo;

public class WishlistServiceImpl implements WishlistService {

	@Autowired
	private WishlistRepo repo;

	@Autowired
	private ProductRepo productrepo;
	
	WishList wishlist = new WishList();
	
//	@Override
//	public List<Product> getAllProducts(Customer customer) {
//		wishlist.setCustomerFromWishList(customer);
//		//wishlist.getCustomerFromWishList().a
//		wishlist.setCustomer(customer);
//		List<Product> products = wishlist.getProduct();
//	//	List<Product> products = (List<Product>)repo.findAll();
//		return products;
//	}

	@Override
	public String addProduct(Product product) {
		//wishlist.addProduct(product);
		productrepo.save(product);
		return "sara";
	}
	

	@Override
	public String addCustomer(Customer customer) {
		wishlist.setCustomer(customer);
		return null;
	}

	
	
}
